/*
 * Global.cpp
 *
 *  Created on: 2011-9-26
 *      Author: Junhao Gan
 */

#define GLOBAL_CPP
#include "headers.h"

