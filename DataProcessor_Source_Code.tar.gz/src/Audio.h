/*
 * Audio.h
 *
 *  Created on: 2011-9-26
 *      Author: Junhao Gan
 */

#ifndef AUDIO_H_
#define AUDIO_H_

#include "headers.h"

//读取二进制数据集
void readAudioBinaryDataSet(char *filename, int n, int d);

#endif /* AUDIO_H_ */
