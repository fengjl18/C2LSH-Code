/*
 * C2LSH_RAM.h
 *
 *  Created on: 2012-6-21
 *      Author: Junhao Gan
 */

#ifndef C2LSH_RAM_H_
#define C2LSH_RAM_H_

int CollisionCount_RAM(PC2StructureT collisionCountStruct, PPointT q, int nNNs);

#endif /* C2LSH_RAM_H_ */
